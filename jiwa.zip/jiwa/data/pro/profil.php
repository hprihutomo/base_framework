

<!-- <div id="lit"> -->
<ul>
	<li><strong>Dr. Kartini Kartono, 2010.</strong> <br>Patologi Sosial. Gangguan-Gangguan Kejiwaan</li>
	<li><strong>Dr. Namora Lumongga Lubis, 2009.</strong><br>Depresi Tinjauan Psikologis</li>
	<li><strong>Dr. Rudi Masli, 2001.</strong> <br>Buku saku Diagnosis Gangguan Jiwa</li>
</ul>
<!-- </div> -->
