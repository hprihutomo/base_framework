<p align="center"><img src="./images/admin.png" alt="Admin" border="0" /></p>
	<p align="center"><font color="#009933" size="2" face="verdana"><br />SELAMAT DATANG ADMINISTRATOR</font></p>
	<p align="center"><font color="#009933" size="2" face="verdana"><br />Silahkan pilih menu yang akan anda kerjakan.</font></p>